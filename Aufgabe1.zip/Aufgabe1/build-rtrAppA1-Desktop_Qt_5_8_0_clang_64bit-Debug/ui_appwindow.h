/********************************************************************************
** Form generated from reading UI file 'appwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APPWINDOW_H
#define UI_APPWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "rtrglwidget.h"

QT_BEGIN_NAMESPACE

class Ui_AppWindow
{
public:
    QHBoxLayout *appWindowLayout;
    rtrGLWidget *openGLWidget;
    QWidget *ui_container;
    QVBoxLayout *verticalLayout;
    QComboBox *modelComboBox;
    QPushButton *quitButton;
    QLabel *label_Rotate_Y;
    QSlider *horizontalSlider_Y;
    QLabel *label_Rotate_X;
    QSlider *horizontalSlider_X;
    QLabel *label_Rotate_Z;
    QSlider *horizontalSlider_Z;
    QSpacerItem *verticalSpacer;
    QLabel *label;

    void setupUi(QWidget *AppWindow)
    {
        if (AppWindow->objectName().isEmpty())
            AppWindow->setObjectName(QStringLiteral("AppWindow"));
        AppWindow->resize(661, 453);
        appWindowLayout = new QHBoxLayout(AppWindow);
        appWindowLayout->setObjectName(QStringLiteral("appWindowLayout"));
        openGLWidget = new rtrGLWidget(AppWindow);
        openGLWidget->setObjectName(QStringLiteral("openGLWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(openGLWidget->sizePolicy().hasHeightForWidth());
        openGLWidget->setSizePolicy(sizePolicy);

        appWindowLayout->addWidget(openGLWidget);

        ui_container = new QWidget(AppWindow);
        ui_container->setObjectName(QStringLiteral("ui_container"));
        verticalLayout = new QVBoxLayout(ui_container);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        modelComboBox = new QComboBox(ui_container);
        modelComboBox->setObjectName(QStringLiteral("modelComboBox"));

        verticalLayout->addWidget(modelComboBox);

        quitButton = new QPushButton(ui_container);
        quitButton->setObjectName(QStringLiteral("quitButton"));

        verticalLayout->addWidget(quitButton);

        label_Rotate_Y = new QLabel(ui_container);
        label_Rotate_Y->setObjectName(QStringLiteral("label_Rotate_Y"));

        verticalLayout->addWidget(label_Rotate_Y);

        horizontalSlider_Y = new QSlider(ui_container);
        horizontalSlider_Y->setObjectName(QStringLiteral("horizontalSlider_Y"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(horizontalSlider_Y->sizePolicy().hasHeightForWidth());
        horizontalSlider_Y->setSizePolicy(sizePolicy1);
        horizontalSlider_Y->setMinimum(-100);
        horizontalSlider_Y->setMaximum(100);
        horizontalSlider_Y->setOrientation(Qt::Horizontal);

        verticalLayout->addWidget(horizontalSlider_Y);

        label_Rotate_X = new QLabel(ui_container);
        label_Rotate_X->setObjectName(QStringLiteral("label_Rotate_X"));

        verticalLayout->addWidget(label_Rotate_X);

        horizontalSlider_X = new QSlider(ui_container);
        horizontalSlider_X->setObjectName(QStringLiteral("horizontalSlider_X"));
        sizePolicy1.setHeightForWidth(horizontalSlider_X->sizePolicy().hasHeightForWidth());
        horizontalSlider_X->setSizePolicy(sizePolicy1);
        horizontalSlider_X->setMinimum(-100);
        horizontalSlider_X->setMaximum(100);
        horizontalSlider_X->setOrientation(Qt::Horizontal);

        verticalLayout->addWidget(horizontalSlider_X);

        label_Rotate_Z = new QLabel(ui_container);
        label_Rotate_Z->setObjectName(QStringLiteral("label_Rotate_Z"));

        verticalLayout->addWidget(label_Rotate_Z);

        horizontalSlider_Z = new QSlider(ui_container);
        horizontalSlider_Z->setObjectName(QStringLiteral("horizontalSlider_Z"));
        sizePolicy1.setHeightForWidth(horizontalSlider_Z->sizePolicy().hasHeightForWidth());
        horizontalSlider_Z->setSizePolicy(sizePolicy1);
        horizontalSlider_Z->setMinimum(-100);
        horizontalSlider_Z->setMaximum(100);
        horizontalSlider_Z->setOrientation(Qt::Horizontal);

        verticalLayout->addWidget(horizontalSlider_Z);

        verticalSpacer = new QSpacerItem(20, 368, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        label = new QLabel(ui_container);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);


        appWindowLayout->addWidget(ui_container);


        retranslateUi(AppWindow);

        modelComboBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(AppWindow);
    } // setupUi

    void retranslateUi(QWidget *AppWindow)
    {
        AppWindow->setWindowTitle(QApplication::translate("AppWindow", "RTR Demo", Q_NULLPTR));
        modelComboBox->clear();
        modelComboBox->insertItems(0, QStringList()
         << QApplication::translate("AppWindow", "Duck", Q_NULLPTR)
         << QApplication::translate("AppWindow", "Bunny", Q_NULLPTR)
         << QApplication::translate("AppWindow", "Teddy", Q_NULLPTR)
         << QApplication::translate("AppWindow", "Trefoil", Q_NULLPTR)
        );
        quitButton->setText(QApplication::translate("AppWindow", "Quit", Q_NULLPTR));
        label_Rotate_Y->setText(QApplication::translate("AppWindow", "Rotate Y:", Q_NULLPTR));
        label_Rotate_X->setText(QApplication::translate("AppWindow", "Rotate X:", Q_NULLPTR));
        label_Rotate_Z->setText(QApplication::translate("AppWindow", "Rotate Z:", Q_NULLPTR));
        label->setText(QApplication::translate("AppWindow", "'h': show/hide UI", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class AppWindow: public Ui_AppWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APPWINDOW_H
