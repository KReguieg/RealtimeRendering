#pragma once

#include "mesh/geometrybuffers.h"

namespace geom {

class Cube : public GeometryBuffers
{
public:
    Cube();
};

} // geom::

