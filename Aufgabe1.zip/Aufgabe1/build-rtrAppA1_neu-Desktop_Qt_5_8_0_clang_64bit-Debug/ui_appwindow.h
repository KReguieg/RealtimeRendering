/********************************************************************************
** Form generated from reading UI file 'appwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APPWINDOW_H
#define UI_APPWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "rtrglwidget.h"

QT_BEGIN_NAMESPACE

class Ui_AppWindow
{
public:
    QHBoxLayout *appWindowLayout;
    rtrGLWidget *openGLWidget;
    QWidget *ui_container;
    QVBoxLayout *verticalLayout;
    QLabel *label_model;
    QComboBox *modelComboBox;
    QLabel *label_position;
    QHBoxLayout *horizontalLayout_positionbox;
    QLabel *label_x_position;
    QSlider *horizontal_x_position;
    QLabel *label_y_position;
    QSlider *horizontalSlider_y_position;
    QLabel *label_z_position;
    QSlider *horizontalSlider_z_position;
    QLabel *label_rotation;
    QHBoxLayout *horizontalLayout_rotationbox;
    QLabel *label_x_rotation;
    QSlider *horizontalSlider_x_rotation;
    QLabel *label_y_rotation;
    QSlider *horizontalSlider_y_rotation;
    QLabel *label_z_rotation;
    QSlider *horizontalSlider_z_rotation;
    QLabel *label_scale;
    QHBoxLayout *horizontalLayout_scalebox;
    QLabel *label_x_scale;
    QSlider *horizontalSlider_x_scale;
    QLabel *label_y_scale;
    QSlider *horizontalSlider_y_scale;
    QLabel *label_z_scale;
    QSlider *horizontalSlider_z_scale;
    QLabel *label_shader;
    QHBoxLayout *horizontalLayout_shaderbox;
    QLabel *label_cel_level;
    QSpinBox *spinBox_cel_level;
    QLabel *label_color;
    QHBoxLayout *horizontalLayout_colorPicker;
    QPushButton *pushButton_colorPicker;
    QHBoxLayout *horizontalLayout_DotShaderBox;
    QVBoxLayout *verticalLayout_dotProperiesLabels;
    QLabel *label_radius;
    QLabel *label_density;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout;
    QSpinBox *spinBox_radius;
    QSpinBox *spinBox_density;
    QSpacerItem *verticalSpacer;
    QPushButton *quitButton;
    QLabel *label_show_hide_gui;

    void setupUi(QWidget *AppWindow)
    {
        if (AppWindow->objectName().isEmpty())
            AppWindow->setObjectName(QStringLiteral("AppWindow"));
        AppWindow->resize(661, 456);
        appWindowLayout = new QHBoxLayout(AppWindow);
        appWindowLayout->setObjectName(QStringLiteral("appWindowLayout"));
        openGLWidget = new rtrGLWidget(AppWindow);
        openGLWidget->setObjectName(QStringLiteral("openGLWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(openGLWidget->sizePolicy().hasHeightForWidth());
        openGLWidget->setSizePolicy(sizePolicy);
        openGLWidget->setFocusPolicy(Qt::StrongFocus);

        appWindowLayout->addWidget(openGLWidget);

        ui_container = new QWidget(AppWindow);
        ui_container->setObjectName(QStringLiteral("ui_container"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(ui_container->sizePolicy().hasHeightForWidth());
        ui_container->setSizePolicy(sizePolicy1);
        ui_container->setMaximumSize(QSize(200, 16777215));
        verticalLayout = new QVBoxLayout(ui_container);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label_model = new QLabel(ui_container);
        label_model->setObjectName(QStringLiteral("label_model"));

        verticalLayout->addWidget(label_model);

        modelComboBox = new QComboBox(ui_container);
        modelComboBox->setObjectName(QStringLiteral("modelComboBox"));
        modelComboBox->setFocusPolicy(Qt::NoFocus);

        verticalLayout->addWidget(modelComboBox);

        label_position = new QLabel(ui_container);
        label_position->setObjectName(QStringLiteral("label_position"));

        verticalLayout->addWidget(label_position);

        horizontalLayout_positionbox = new QHBoxLayout();
        horizontalLayout_positionbox->setObjectName(QStringLiteral("horizontalLayout_positionbox"));
        label_x_position = new QLabel(ui_container);
        label_x_position->setObjectName(QStringLiteral("label_x_position"));

        horizontalLayout_positionbox->addWidget(label_x_position);

        horizontal_x_position = new QSlider(ui_container);
        horizontal_x_position->setObjectName(QStringLiteral("horizontal_x_position"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(horizontal_x_position->sizePolicy().hasHeightForWidth());
        horizontal_x_position->setSizePolicy(sizePolicy2);
        horizontal_x_position->setMinimum(-99);
        horizontal_x_position->setOrientation(Qt::Horizontal);

        horizontalLayout_positionbox->addWidget(horizontal_x_position);

        label_y_position = new QLabel(ui_container);
        label_y_position->setObjectName(QStringLiteral("label_y_position"));

        horizontalLayout_positionbox->addWidget(label_y_position);

        horizontalSlider_y_position = new QSlider(ui_container);
        horizontalSlider_y_position->setObjectName(QStringLiteral("horizontalSlider_y_position"));
        horizontalSlider_y_position->setMinimum(-99);
        horizontalSlider_y_position->setOrientation(Qt::Horizontal);

        horizontalLayout_positionbox->addWidget(horizontalSlider_y_position);

        label_z_position = new QLabel(ui_container);
        label_z_position->setObjectName(QStringLiteral("label_z_position"));

        horizontalLayout_positionbox->addWidget(label_z_position);

        horizontalSlider_z_position = new QSlider(ui_container);
        horizontalSlider_z_position->setObjectName(QStringLiteral("horizontalSlider_z_position"));
        horizontalSlider_z_position->setMinimum(-99);
        horizontalSlider_z_position->setOrientation(Qt::Horizontal);

        horizontalLayout_positionbox->addWidget(horizontalSlider_z_position);


        verticalLayout->addLayout(horizontalLayout_positionbox);

        label_rotation = new QLabel(ui_container);
        label_rotation->setObjectName(QStringLiteral("label_rotation"));

        verticalLayout->addWidget(label_rotation);

        horizontalLayout_rotationbox = new QHBoxLayout();
        horizontalLayout_rotationbox->setObjectName(QStringLiteral("horizontalLayout_rotationbox"));
        label_x_rotation = new QLabel(ui_container);
        label_x_rotation->setObjectName(QStringLiteral("label_x_rotation"));

        horizontalLayout_rotationbox->addWidget(label_x_rotation);

        horizontalSlider_x_rotation = new QSlider(ui_container);
        horizontalSlider_x_rotation->setObjectName(QStringLiteral("horizontalSlider_x_rotation"));
        horizontalSlider_x_rotation->setMinimum(-10);
        horizontalSlider_x_rotation->setMaximum(10);
        horizontalSlider_x_rotation->setOrientation(Qt::Horizontal);

        horizontalLayout_rotationbox->addWidget(horizontalSlider_x_rotation);

        label_y_rotation = new QLabel(ui_container);
        label_y_rotation->setObjectName(QStringLiteral("label_y_rotation"));

        horizontalLayout_rotationbox->addWidget(label_y_rotation);

        horizontalSlider_y_rotation = new QSlider(ui_container);
        horizontalSlider_y_rotation->setObjectName(QStringLiteral("horizontalSlider_y_rotation"));
        horizontalSlider_y_rotation->setMinimum(-360);
        horizontalSlider_y_rotation->setMaximum(360);
        horizontalSlider_y_rotation->setOrientation(Qt::Horizontal);

        horizontalLayout_rotationbox->addWidget(horizontalSlider_y_rotation);

        label_z_rotation = new QLabel(ui_container);
        label_z_rotation->setObjectName(QStringLiteral("label_z_rotation"));

        horizontalLayout_rotationbox->addWidget(label_z_rotation);

        horizontalSlider_z_rotation = new QSlider(ui_container);
        horizontalSlider_z_rotation->setObjectName(QStringLiteral("horizontalSlider_z_rotation"));
        horizontalSlider_z_rotation->setMinimum(-360);
        horizontalSlider_z_rotation->setMaximum(360);
        horizontalSlider_z_rotation->setOrientation(Qt::Horizontal);

        horizontalLayout_rotationbox->addWidget(horizontalSlider_z_rotation);


        verticalLayout->addLayout(horizontalLayout_rotationbox);

        label_scale = new QLabel(ui_container);
        label_scale->setObjectName(QStringLiteral("label_scale"));

        verticalLayout->addWidget(label_scale);

        horizontalLayout_scalebox = new QHBoxLayout();
        horizontalLayout_scalebox->setObjectName(QStringLiteral("horizontalLayout_scalebox"));
        label_x_scale = new QLabel(ui_container);
        label_x_scale->setObjectName(QStringLiteral("label_x_scale"));

        horizontalLayout_scalebox->addWidget(label_x_scale);

        horizontalSlider_x_scale = new QSlider(ui_container);
        horizontalSlider_x_scale->setObjectName(QStringLiteral("horizontalSlider_x_scale"));
        horizontalSlider_x_scale->setMinimum(-99);
        horizontalSlider_x_scale->setOrientation(Qt::Horizontal);

        horizontalLayout_scalebox->addWidget(horizontalSlider_x_scale);

        label_y_scale = new QLabel(ui_container);
        label_y_scale->setObjectName(QStringLiteral("label_y_scale"));

        horizontalLayout_scalebox->addWidget(label_y_scale);

        horizontalSlider_y_scale = new QSlider(ui_container);
        horizontalSlider_y_scale->setObjectName(QStringLiteral("horizontalSlider_y_scale"));
        horizontalSlider_y_scale->setMinimum(-99);
        horizontalSlider_y_scale->setOrientation(Qt::Horizontal);

        horizontalLayout_scalebox->addWidget(horizontalSlider_y_scale);

        label_z_scale = new QLabel(ui_container);
        label_z_scale->setObjectName(QStringLiteral("label_z_scale"));

        horizontalLayout_scalebox->addWidget(label_z_scale);

        horizontalSlider_z_scale = new QSlider(ui_container);
        horizontalSlider_z_scale->setObjectName(QStringLiteral("horizontalSlider_z_scale"));
        horizontalSlider_z_scale->setMinimum(-99);
        horizontalSlider_z_scale->setOrientation(Qt::Horizontal);

        horizontalLayout_scalebox->addWidget(horizontalSlider_z_scale);


        verticalLayout->addLayout(horizontalLayout_scalebox);

        label_shader = new QLabel(ui_container);
        label_shader->setObjectName(QStringLiteral("label_shader"));

        verticalLayout->addWidget(label_shader);

        horizontalLayout_shaderbox = new QHBoxLayout();
        horizontalLayout_shaderbox->setObjectName(QStringLiteral("horizontalLayout_shaderbox"));
        label_cel_level = new QLabel(ui_container);
        label_cel_level->setObjectName(QStringLiteral("label_cel_level"));

        horizontalLayout_shaderbox->addWidget(label_cel_level);

        spinBox_cel_level = new QSpinBox(ui_container);
        spinBox_cel_level->setObjectName(QStringLiteral("spinBox_cel_level"));
        spinBox_cel_level->setMinimum(1);
        spinBox_cel_level->setMaximum(12);
        spinBox_cel_level->setValue(3);

        horizontalLayout_shaderbox->addWidget(spinBox_cel_level);


        verticalLayout->addLayout(horizontalLayout_shaderbox);

        label_color = new QLabel(ui_container);
        label_color->setObjectName(QStringLiteral("label_color"));

        verticalLayout->addWidget(label_color);

        horizontalLayout_colorPicker = new QHBoxLayout();
        horizontalLayout_colorPicker->setObjectName(QStringLiteral("horizontalLayout_colorPicker"));
        pushButton_colorPicker = new QPushButton(ui_container);
        pushButton_colorPicker->setObjectName(QStringLiteral("pushButton_colorPicker"));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(0, 0, 255, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(127, 127, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(63, 63, 255, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(0, 0, 127, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(0, 0, 170, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush6(QColor(255, 255, 255, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush2);
        QBrush brush7(QColor(255, 255, 220, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush7);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush7);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush7);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        pushButton_colorPicker->setPalette(palette);

        horizontalLayout_colorPicker->addWidget(pushButton_colorPicker);


        verticalLayout->addLayout(horizontalLayout_colorPicker);

        horizontalLayout_DotShaderBox = new QHBoxLayout();
        horizontalLayout_DotShaderBox->setObjectName(QStringLiteral("horizontalLayout_DotShaderBox"));
        verticalLayout_dotProperiesLabels = new QVBoxLayout();
        verticalLayout_dotProperiesLabels->setObjectName(QStringLiteral("verticalLayout_dotProperiesLabels"));
        label_radius = new QLabel(ui_container);
        label_radius->setObjectName(QStringLiteral("label_radius"));

        verticalLayout_dotProperiesLabels->addWidget(label_radius);

        label_density = new QLabel(ui_container);
        label_density->setObjectName(QStringLiteral("label_density"));

        verticalLayout_dotProperiesLabels->addWidget(label_density);


        horizontalLayout_DotShaderBox->addLayout(verticalLayout_dotProperiesLabels);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        spinBox_radius = new QSpinBox(ui_container);
        spinBox_radius->setObjectName(QStringLiteral("spinBox_radius"));
        spinBox_radius->setMaximum(100);
        spinBox_radius->setSingleStep(10);
        spinBox_radius->setValue(10);

        horizontalLayout->addWidget(spinBox_radius);


        verticalLayout_2->addLayout(horizontalLayout);

        spinBox_density = new QSpinBox(ui_container);
        spinBox_density->setObjectName(QStringLiteral("spinBox_density"));
        spinBox_density->setValue(4);

        verticalLayout_2->addWidget(spinBox_density);


        horizontalLayout_DotShaderBox->addLayout(verticalLayout_2);


        verticalLayout->addLayout(horizontalLayout_DotShaderBox);

        verticalSpacer = new QSpacerItem(20, 368, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        quitButton = new QPushButton(ui_container);
        quitButton->setObjectName(QStringLiteral("quitButton"));

        verticalLayout->addWidget(quitButton);

        label_show_hide_gui = new QLabel(ui_container);
        label_show_hide_gui->setObjectName(QStringLiteral("label_show_hide_gui"));

        verticalLayout->addWidget(label_show_hide_gui);


        appWindowLayout->addWidget(ui_container);


        retranslateUi(AppWindow);

        modelComboBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(AppWindow);
    } // setupUi

    void retranslateUi(QWidget *AppWindow)
    {
        AppWindow->setWindowTitle(QApplication::translate("AppWindow", "RTR Demo", Q_NULLPTR));
        label_model->setText(QApplication::translate("AppWindow", "Model:", Q_NULLPTR));
        modelComboBox->clear();
        modelComboBox->insertItems(0, QStringList()
         << QApplication::translate("AppWindow", "Duck", Q_NULLPTR)
         << QApplication::translate("AppWindow", "Trefoil", Q_NULLPTR)
         << QApplication::translate("AppWindow", "Cube", Q_NULLPTR)
         << QApplication::translate("AppWindow", "Bunny", Q_NULLPTR)
         << QApplication::translate("AppWindow", "Teddy", Q_NULLPTR)
        );
        label_position->setText(QApplication::translate("AppWindow", "Position:", Q_NULLPTR));
        label_x_position->setText(QApplication::translate("AppWindow", "X:", Q_NULLPTR));
        label_y_position->setText(QApplication::translate("AppWindow", "Y:", Q_NULLPTR));
        label_z_position->setText(QApplication::translate("AppWindow", "Z:", Q_NULLPTR));
        label_rotation->setText(QApplication::translate("AppWindow", "Rotation:", Q_NULLPTR));
        label_x_rotation->setText(QApplication::translate("AppWindow", "X:", Q_NULLPTR));
        label_y_rotation->setText(QApplication::translate("AppWindow", "Y:", Q_NULLPTR));
        label_z_rotation->setText(QApplication::translate("AppWindow", "Z:", Q_NULLPTR));
        label_scale->setText(QApplication::translate("AppWindow", "Scale:", Q_NULLPTR));
        label_x_scale->setText(QApplication::translate("AppWindow", "X:", Q_NULLPTR));
        label_y_scale->setText(QApplication::translate("AppWindow", "Y:", Q_NULLPTR));
        label_z_scale->setText(QApplication::translate("AppWindow", "Z:", Q_NULLPTR));
        label_shader->setText(QApplication::translate("AppWindow", "Shader:", Q_NULLPTR));
        label_cel_level->setText(QApplication::translate("AppWindow", "Cel-Shader Level:", Q_NULLPTR));
        label_color->setText(QApplication::translate("AppWindow", "Color:", Q_NULLPTR));
        pushButton_colorPicker->setText(QString());
        label_radius->setText(QApplication::translate("AppWindow", "Radius:", Q_NULLPTR));
        label_density->setText(QApplication::translate("AppWindow", "Density:", Q_NULLPTR));
        quitButton->setText(QApplication::translate("AppWindow", "Quit", Q_NULLPTR));
        label_show_hide_gui->setText(QApplication::translate("AppWindow", "'h': show/hide UI", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class AppWindow: public Ui_AppWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APPWINDOW_H
